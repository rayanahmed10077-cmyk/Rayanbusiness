# AI Business Operator — Production Foundation

An evidence-first AI operator for a website-service business. It automates research, analysis, demo planning and outreach drafting while keeping human approval gates for leads, outreach, payment and delivery.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Netlify

Build command: `npm run build`  
Publish directory: `dist`

Set server-side environment variables from `.env.example`. Never commit API keys.

Required for live AI/research:
- `TAVILY_API_KEY`
- `OPENAI_API_KEY`

Optional future integrations:
- `RESEND_API_KEY`
- `NETLIFY_AUTH_TOKEN`
- `NETLIFY_SITE_ID`

## Safety / correctness

- Research leads keep source URLs and evidence excerpts.
- The system does not claim simulated businesses are real.
- AI is instructed not to invent business facts.
- Outreach is prepared, not automatically sent.
- Payment/deal progression is manually gated.
- Deployment is not claimed until an actual deployment integration is configured.
- API secrets stay server-side.
