# AI Business Operator — gated MVP

This project is intentionally built as a **truthful workflow shell**. It does not claim that live research, AI generation, outreach, deployment, or payments are connected when they are not.

## Current workflow
1. **Prospect Scout** — creates a research job definition and accepts manually sourced leads for testing.
2. **Evidence gate** — a prospect cannot be approved without a source URL.
3. **Demo Factory** — only approved leads can enter; verified inputs and AI-generated outputs are kept separate.
4. **Demo approval** — human approval required.
5. **Outreach preparation** — prepares the next stage but does not silently send messages.
6. **Send approval** — human approval required before outreach execution.
7. **Client acceptance/payment checkpoint** — build is blocked until the operator records acceptance/payment.
8. **Build & QA** — unlocked only after acceptance/payment is recorded.
9. **Delivery approval** — human approval required before marking a project delivered.

## Important
The current UI is an MVP workflow simulator/local state app. The following integrations are intentionally **not connected**:
- live web research
- LLM provider
- database/CRM
- email/outreach provider
- Git provider
- Netlify deployment
- payment provider

Do not put provider API keys in frontend code. Use a server-side backend for secrets and external actions.

## Run locally
Requires Node.js 20+.

```bash
npm install
npm run dev
```

The environment used to prepare this project timed out while downloading npm dependencies, so the dependency installation was not verified here.
